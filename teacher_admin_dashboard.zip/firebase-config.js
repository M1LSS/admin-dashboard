const firebaseConfig = {
  apiKey: "AIzaSyAtbaEMPmljXmEfUU7k00obcIh4WVfDo3Y",
  authDomain: "gdp-project-7831b.firebaseapp.com",
  databaseURL: "https://gdp-project-7831b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "gdp-project-7831b",
  storageBucket: "gdp-project-7831b.appspot.com",
  messagingSenderId: "",
  appId: ""
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();